# VYRA v1.0 — Windows desktop AI + creator studio

VYRA is an independent, local-first desktop AI workspace inspired by the clarity of modern AI chats and the navigational polish of game launchers. **This build is not Electron**: `VYRA.exe` is a native Windows x64 executable written in Go. It runs an embedded private localhost server and opens Microsoft Edge in a dedicated app window. The main AI chat works without Python, Node, Electron, or an installer. It requires internet and your own OpenAI API key. The optional VYRA Clips worker needs Python and FFmpeg.

## Run on Windows

1. Extract `VYRA-Windows-v1.zip` to a folder you control, e.g. `C:\Users\<you>\Apps\VYRA`.
2. Double-click **VYRA.exe**. It opens a dedicated Microsoft Edge app window; on fallback, your default browser opens.
3. Go to **Settings & connections** and enter your own OpenAI API key. Select the option to encrypt and remember it with Windows DPAPI.
4. Open **Intelligence** and start chatting.
5. For **VYRA Clips**, install Python 3.11+, FFmpeg with libass and run **SETUP_CLIPS.bat** once; then press **Launch Clips Studio**. The worker uses your same local OpenAI key in-process.
6. Close VYRA from **Settings > Exit VYRA** to stop its local backend. Closing only the app window doesn't automatically terminate the background local process.

**Privacy:** The desktop app listens only on `127.0.0.1:48791`, rejects nonlocal Hosts, requires a random session token for mutations, and saves keys encrypted through Windows DPAPI. Chat history and projects are stored in browser local storage for that origin, *not* synced to a cloud server. Your chats are sent to OpenAI under your own API key when submitted; `store:false` is requested. The AI backend has no access to your computer beyond messages you submit. Never put keys into the public site or share secret environment files.

**Website:** the `website/` directory is a separate, static marketing page plus a UI-only `/studio` preview. The preview does not have a server and cannot make AI requests. Deploy `website` as the Vercel project root. Update download links after the GitHub Windows release publishes.

**VYRA Clips:** the `clips-worker/` directory contains the video clipping + publishing code from VYRA Clips v0.2, including locally rendered videos, OpenAI transcription and highlight selection, optional social OAuth, and an approval queue. It is *not* fully integrated into the native executable; clicking Launch starts the local Python worker and opens its window. Live posting hasn't been validated, and YouTube/Instagram/TikTok developer accounts/approvals are required.

**Status of this release:** the Windows executable cross-compiled successfully on Linux and is a valid 64-bit PE binary. The browser UI assets passed JavaScript syntax checks but a full desktop visual test was unavailable in this environment. An actual Windows 10/11 double-click test, Edge compatibility and signed installer packaging have not been performed. There is no bundled Python or FFmpeg. Windows SmartScreen may warn about an unsigned program. Do not bypass security controls on untrusted software.

## Build from source

Use [Go 1.23+](https://go.dev/dl/) on Windows: `BUILD_WINDOWS_EXE.bat`, or on Linux: `GOOS=windows GOARCH=amd64 go build -trimpath -ldflags='-H=windowsgui -s -w' -o VYRA.exe .`

Do not confuse an EXE with an installer: this release contains a *portable application*, not a signed NSIS installer. The marketing site links to GitHub Releases for future signed builds. Development source and static website are included in `VYRA-Source-v1.zip`.
